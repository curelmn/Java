package org.example.base;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseEntity {
    private Integer pageNumber;
    private Integer pageSize;
    private String searchText;
    private String sortOrder;
}
