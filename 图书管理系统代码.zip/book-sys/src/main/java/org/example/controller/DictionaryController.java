package org.example.controller;

//@RestController
//@RequestMapping("")
public class DictionaryController {
}
